# currency-tracker
Addon for World of Warcraft: Mists of Pandaria Classic to track the currencies over multiple characters.
